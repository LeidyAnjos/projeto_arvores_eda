#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct login{
    char usuario[25];
    char senha[20];
}Login;

void _tela_inicial();
/*
Login tela_login();
Login escrever_login(Login l, FILE *Arquivo_login);


int  validaSenha(char senha[]);
*/